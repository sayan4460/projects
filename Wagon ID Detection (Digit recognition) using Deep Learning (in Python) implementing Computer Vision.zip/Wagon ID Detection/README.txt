The objective of this project was to import the MNIST data containing 70, 000 grayscale, 
28x28 pixels images of handwritten digits using Keras in Jupyter Notebook workspace, train 
a Multilayer Perceptron (sequential model) with 60, 000 images adding backpropagation 
algorithm and test the trained class of Neural Network on the remaining 10, 000 images for 
accuracy in Python.

1. install Anaconda 5.2 Python 3.6 version
2. import and run wagoniddetection.ipynb in Jupyter Notebook