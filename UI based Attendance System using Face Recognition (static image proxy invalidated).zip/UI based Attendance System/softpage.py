#import module from tkinter for UI
from Tkinter import *
import os
from datetime import datetime;
from PIL import Image,ImageTk
#creating instance of TK
root=Tk()

photo=ImageTk.PhotoImage(Image.open("200628.jpg"))
'''photo1=ImageTk.PhotoImage(Image.open("E:\\internship project and training\\6th semester minor project\\coding\\final\\Buttons\\1.jpg"))
photo2=ImageTk.PhotoImage(Image.open("E:\\internship project and training\\6th semester minor project\\coding\\final\\Buttons\\2.jpg"))
photo3=ImageTk.PhotoImage(Image.open("E:\\internship project and training\\6th semester minor project\\coding\\final\\Buttons\\3.jpg"))
photo4=ImageTk.PhotoImage(Image.open("E:\\internship project and training\\6th semester minor project\\coding\\final\\Buttons\\4.jpg"))
photo5=ImageTk.PhotoImage(Image.open("E:\\internship project and training\\6th semester minor project\\coding\\final\\Buttons\\5.jpg"))
photo6=ImageTk.PhotoImage(Image.open("E:\\internship project and training\\6th semester minor project\\coding\\final\\Buttons\\6.jpg"))
photo7=ImageTk.PhotoImage(Image.open("E:\\internship project and training\\6th semester minor project\\coding\\final\\Buttons\\7.jpg"))
'''
root.configure(background='black')

root.geometry("1000x668")
def creator():
    
    os.system("dataSetCreator.py")
    
def train():
    
    os.system("trainner.py")

def takeattend():

    os.system("detector.py")
    

def close():

    root.destroy()

def attend():
    os.startfile("attendance\\"+str(datetime.now().date())+'.xls')
def slide():
    os.startfile("frs"+'.pptx')


#setting title for the window
root.title("FACE RECOGNITION ATTENDANCE SYSTEM")
Label(root,image=photo,bg='black',height=650,width=983).grid(row=0,rowspan=380,columnspan=100,sticky=N+E+W+S,padx=7,pady=7)
#Label(root, text="FACE RECOGNITION ATTENDANCE SYSTEM",font=("forte",20,'bold'),fg="black",bg="red",height=3,width=75).grid(row=0,rowspan=2,columnspan=2,sticky=N+E+W+S,padx=7,pady=7)

Button(root,text="DataSet Creator",font=("arial",16,'bold','italic'),bg="gray",fg='black',command=creator,height=0,width=18).grid(row=320,column=0,columnspan=2,sticky=W+E+N+S,padx=70,pady=7)

Button(root,text="Train Dataset",font=("arial",16,'bold','italic'),bg="gray",fg='black',command=train,height=1,width=18).grid(row=330,column=0,columnspan=2,sticky=N+E+W+S,padx=70,pady=7)

Button(root,text="Recognize + Attendance",font=("arial",14,'bold','italic'),bg="gray",fg="black",command=takeattend,height=1,width=18).grid(row=340,column=0,columnspan=2,sticky=N+E+W+S,padx=70,pady=7)

Button(root,text="View Attendance Sheet",font=("arial",16,'bold','italic'),bg="gray",fg="black",command=attend,height=1,width=18).grid(row=350,column=0,columnspan=2,sticky=N+E+W+S,padx=70,pady=7)

Button(root,text=" Exit  ",font=("arial",16,'bold','italic'),bg="gray",fg="white",command=close,height=1,width=18).grid(row=350,column=96,columnspan=4,sticky=N+E+W+S,padx=60,pady=7)

Button(root,text="Developers",font=("arial",16,'bold','italic'),bg="gray",fg="white",command=close,height=1,width=18).grid(row=330,column=96,columnspan=4,sticky=N+E+W+S,padx=60,pady=7)
Button(root,text="Project Report",font=("arial",16,'bold','italic'),bg="gray",fg="white",command=slide,height=1,width=18).grid(row=340,column=96,columnspan=4,sticky=N+E+W+S,padx=60,pady=7)



root.mainloop()
