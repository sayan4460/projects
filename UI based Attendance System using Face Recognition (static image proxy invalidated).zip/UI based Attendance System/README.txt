Using LBPH Algorithm (in Python) implementing Computer Vision that mandates blink and smile
 on face in order to discard static image proxy attempt, taken forward to save daily 
attendance in sqlite database and email the same

1. install python-2.7.15
2. download and extract opencv-2.4.13.6-vc14 to opencv
3. copy cv2.pyd from opencv\build\python\2.7\x64 or opencv\build\python\2.7\x86 to 
	C:\Python27\Lib\site-packages
4. run cmd and type cd C:\Python27\Scripts
5. install the following libraries:
	pillow		(pip install pillow)
	numpy		(pip install numpy)
	playsound	(pip install playsound)
	xlsxwriter	(pip install xlsxwriter)
	xlwt		(pip install xlwt)
	xlrd		(pip install xlrd)
	xlutils		(pip install xlutils)
	pathlib		(pip install pathlib)
6. run softpage.py